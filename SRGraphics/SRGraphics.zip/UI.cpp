#include "pch.h"
#include "UI.h"
#include "Window.h"

float SpaRcle::Graphics::UI::XPosCorrect() const {
	return x_pos * win->format->x_left_side_pos_magic_number / 2.20625f;
}
float SpaRcle::Graphics::UI::YPosCorrect() const {
	if(win->EditorMode)
		return y_pos + 74.f / win->format->size_y; // 74 - it is size tool bar
	else
		return y_pos;
}

float SpaRcle::Graphics::UI::YSizeCorrect() const {
	return y_size;
}
