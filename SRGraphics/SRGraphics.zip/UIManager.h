#pragma once


namespace SpaRcle {
	namespace Graphics {
		namespace GUI {
			class GUIManager {
				GUIManager() {
					// Create the renderer.
					//Gwen::Renderer::OpenGL* opengl = new Gwen::Renderer::OpenGL();
					//opengl->Init();

					//Gwen::TextObject text = Gwen::TextObject(";

					// Create the skin.
					//Gwen::Skin::TexturedBase* gwen_skin = new Gwen::Skin::TexturedBase(opengl);
					//gwen_skin->Init(text);

					// Create the canvas.
					//Gwen::Controls::Canvas* gwen_canvas = new Gwen::Controls::Canvas(gwen_skin);

					//Gwen::Controls::Button* button = new Gwen::Controls::Button(gwen_canvas);
				}
			};
		}
	}
}