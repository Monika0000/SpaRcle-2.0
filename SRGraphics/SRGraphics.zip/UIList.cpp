#include "pch.h"
#include "UIList.h"

//template<typename T> inline void SpaRcle::Graphics::UIList<T>::DrawElements() {  }
//template<typename T> inline void SpaRcle::Graphics::UIList<T>::Draw() {  }

namespace SpaRcle {
	namespace Graphics {

	}
}